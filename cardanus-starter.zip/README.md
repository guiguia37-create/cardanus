# Cardanus - Prototype (Vite + React + Tailwind)

**Clé en main** : ce projet contient un prototype mobile-first pour ton site de cartes "Cardanus".

## Pour l'ouvrir en local
1. Installer Node.js (version 18+ recommandée).
2. Dans le dossier du projet, lancer :
   ````bash
   npm install
   npm run dev
   ````
3. Ouvrir l'URL indiquée par Vite (généralement http://localhost:5173).

## Remarques
- J'ai utilisé `lucide-react` pour les icônes ; si tu veux, tu peux l'ajouter avec `npm install lucide-react` ou remplacer les icônes par ton choix.
- Tailwind est déjà configuré (fichiers `tailwind.config.cjs` et `postcss.config.cjs` inclus).
- Si tu préfères un template `create-react-app` ou CodeSandbox prêt à l'emploi, dis-le moi et je prépare ça.
