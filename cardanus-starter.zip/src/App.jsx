import { useState } from 'react';
import { Home, Bookmark, ShoppingBag, RefreshCw } from 'lucide-react';

export default function App() {
  const [annonces] = useState([
    'Alex a obtenu Carte Rare #57 !',
    'Marie a gagné 50 points journaliers',
    'Nouvelle carte sexy exclusive débloquée !',
  ]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex justify-between items-center p-4 bg-gradient-to-r from-pink-600 to-purple-700 shadow-md">
        <h1 className="text-2xl font-bold tracking-wide">Cardanus</h1>
        <div className="flex items-center space-x-2">
          <img src="https://via.placeholder.com/40" alt="avatar" className="w-10 h-10 rounded-full border-2 border-gold" />
          <span className="font-medium">Pseudo</span>
        </div>
      </header>

      {/* Infos collection */}
      <section className="flex justify-around p-3 text-sm bg-gray-900 border-b border-gray-800">
        <div>
          <p className="font-bold text-pink-400">Rang</p>
          <p>#12</p>
        </div>
        <div>
          <p className="font-bold text-pink-400">Items</p>
          <p>128</p>
        </div>
        <div>
          <p className="font-bold text-pink-400">Points</p>
          <p>+35</p>
        </div>
      </section>

      {/* Bandeau promo */}
      <section className="p-4 bg-gradient-to-r from-purple-800 to-pink-700 text-center font-semibold text-lg">
        🚨 Nouvelle série disponible : "Dark Queens" !
      </section>

      {/* Annonces temps réel */}
      <section className="overflow-hidden h-10 bg-gray-950 border-y border-gray-800 flex items-center">
        <div className="animate-marquee whitespace-nowrap text-sm text-gray-300">
          {annonces.join('   •   ')}
        </div>
      </section>

      {/* Contenu central (placeholder) */}
      <main className="flex-1 flex items-center justify-center text-gray-500">
        <p>Contenu principal ici…</p>
      </main>

      {/* Footer navigation */}
      <footer className="flex justify-around items-center p-3 bg-gray-900 border-t border-gray-800">
        <button className="flex flex-col items-center text-sm">
          <Home />
          Home
        </button>
        <button className="flex flex-col items-center text-sm">
          <Bookmark />
          Collection
        </button>
        <button className="flex flex-col items-center text-sm">
          <ShoppingBag />
          Market
        </button>
        <button className="flex flex-col items-center text-sm">
          <RefreshCw />
          Échange
        </button>
      </footer>
    </div>
  );
}
